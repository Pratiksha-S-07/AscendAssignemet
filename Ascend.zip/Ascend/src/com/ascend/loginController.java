package com.ascend;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class login
 */
@WebServlet("/login")
public class loginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public loginController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		String emp = request.getParameter("email");
		String pass = request.getParameter("password");
		PrintWriter out = response.getWriter();

	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql:///demo","root","Pratiksha");
	PreparedStatement ps = con.prepareStatement("select email from employee where email = ? and password = ?");
	ps.setString(1, emp);
	ps.setString(2, pass);
	ResultSet rs =  ps.executeQuery();

		 if(rs.next())
		 {
			RequestDispatcher rd = request.getRequestDispatcher("todo.html");
			rd.forward(request, response);
		 }
		 else
		 {
			 out.println("<font colour = pink size =20 >Login failed<br>");
			 Thread.sleep(1000);
			 RequestDispatcher rd = request.getRequestDispatcher("login.html");

		 }

	} catch (ClassNotFoundException e) {
		
		e.printStackTrace();
	} catch (SQLException e) {
		
		e.printStackTrace();
	} catch (InterruptedException e) {
		
		e.printStackTrace();
	}

	doGet(request, response);
}

}
	


